import { Component } from '@angular/core';
import { CancionesService } from '../canciones.service';

@Component({
  selector: 'app-inicio',
  standalone: true,
  imports: [],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css'
})
export class InicioComponent {
  canciones:any;

  constructor (private cancionesService:CancionesService){
    this.cancionesService.retornar().subscribe((result) => (this.canciones = result));
    console.log(this.canciones);
  }
}
